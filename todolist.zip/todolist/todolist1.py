import csv
import os


# -------------------------
# Task Class
# -------------------------
class Task:
    def __init__(self, name, description, priority):
        self.name = name
        self.description = description
        self.priority = priority

    def __str__(self):
        return f"Name: {self.name} | Description: {self.description} | Priority: {self.priority}"


# -------------------------
# ToDoList Class
# -------------------------
class ToDoList:
    def __init__(self, filename="tasks.csv"):
        self.tasks = []
        self.filename = filename
        self.load_tasks()

    # Add a new task
    def add_task(self, task):
        self.tasks.append(task)
        self.save_tasks()
        print("Task added successfully.")

    # Remove a task
    def remove_task(self, index):
        if 0 <= index < len(self.tasks):
            removed = self.tasks.pop(index)
            self.save_tasks()
            print(f"Task '{removed.name}' has been removed.")
        else:
            print("Invalid task number.")

    # Display all tasks
    def show_tasks(self):
        if not self.tasks:
            print("\nNo tasks available.\n")
            return

        print("\n========== TO-DO LIST ==========")
        for i, task in enumerate(self.tasks, start=1):
            print(f"{i}. {task}")
        print("================================")

    # Save tasks to CSV file
    def save_tasks(self):
        with open(self.filename, mode="w", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)
            writer.writerow(["Name", "Description", "Priority"])

            for task in self.tasks:
                writer.writerow([
                    task.name,
                    task.description,
                    task.priority
                ])

    # Load tasks from CSV file
    def load_tasks(self):
        if not os.path.exists(self.filename):
            return

        with open(self.filename, mode="r", encoding="utf-8") as file:
            reader = csv.DictReader(file)

            for row in reader:
                task = Task(
                    row["Name"],
                    row["Description"],
                    row["Priority"]
                )
                self.tasks.append(task)


# -------------------------
# Main Menu
# -------------------------
def menu():
    todo = ToDoList()

    while True:
        print("\n========== TO-DO LIST ==========")
        print("1. Add Task")
        print("2. Remove Task")
        print("3. Show Tasks")
        print("4. Exit")
        print("================================")

        choice = input("Choose an option: ")

        if choice == "1":
            name = input("Task Name: ")
            description = input("Task Description: ")

            while True:
                priority = input("Priority (High / Medium / Low): ")

                if priority in ["High", "Medium", "Low"]:
                    break
                else:
                    print("Invalid priority. Please enter High, Medium, or Low.")

            task = Task(name, description, priority)
            todo.add_task(task)

        elif choice == "2":
            todo.show_tasks()

            if len(todo.tasks) > 0:
                try:
                    number = int(input("Enter the task number to remove: "))
                    todo.remove_task(number - 1)
                except ValueError:
                    print("Please enter a valid number.")

        elif choice == "3":
            todo.show_tasks()

        elif choice == "4":
            print("Program terminated.")
            break

        else:
            print("Invalid option. Please try again.")


if __name__ == "__main__":
    menu()