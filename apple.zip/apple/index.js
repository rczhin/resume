var menu = document.querySelector("nav.menu");
var menuButton = document.querySelector(".menuButton");
var backTop = null;

function openMenu() {
  menu.classList.add("open");
  menuButton.textContent = "✕";
  menuButton.setAttribute("aria-expanded", "true");
}

function closeMenu() {
  menu.classList.remove("open");
  menuButton.textContent = "☰";
  menuButton.setAttribute("aria-expanded", "false");
}

function clickMenuButton() {
  if (menu.classList.contains("open")) {
    closeMenu();
  } else {
    openMenu();
  }
}

function startMenu() {
  if (!menu || !menuButton) {
    return;
  }
  menuButton.addEventListener("click", clickMenuButton);

  var links = menu.querySelectorAll(".linkItem a");
  for (var i = 0; i < links.length; i++) {
    links[i].addEventListener("click", closeMenu);
  }

  document.addEventListener("click", function (event) {
    if (!menu.contains(event.target)) {
      closeMenu();
    }
  });

  document.addEventListener("keydown", function (event) {
    if (event.key === "Escape") {
      closeMenu();
    }
  });

  window.addEventListener("resize", function () {
    if (window.innerWidth > 992) {
      closeMenu();
    }
  });
}

function startBackTop() {
  backTop = document.createElement("button");
  backTop.className = "backTop";
  backTop.textContent = "↑";
  backTop.setAttribute("aria-label", "Back to top");
  backTop.addEventListener("click", function () {
    window.scrollTo({ top: 0, behavior: "smooth" });
  });
  document.body.appendChild(backTop);
}

function checkScroll() {
  if (menu) {
    if (window.scrollY > 10) {
      menu.classList.add("scrolled");
    } else {
      menu.classList.remove("scrolled");
    }
  }
  if (backTop) {
    if (window.scrollY > 600) {
      backTop.classList.add("show");
    } else {
      backTop.classList.remove("show");
    }
  }
}

function startReveal() {
  if (!("IntersectionObserver" in window)) {
    return;
  }
  var items = document.querySelectorAll(".p1, .s11");
  var watcher = new IntersectionObserver(
    function (list) {
      for (var i = 0; i < list.length; i++) {
        if (list[i].isIntersecting) {
          list[i].target.classList.add("show");
          watcher.unobserve(list[i].target);
        }
      }
    },
    { threshold: 0.15 }
  );
  for (var j = 0; j < items.length; j++) {
    items[j].classList.add("reveal");
    watcher.observe(items[j]);
  }
}

function clickTitle(event) {
  event.currentTarget.parentNode.classList.toggle("open");
}

function startFooterMenu() {
  var titles = document.querySelectorAll("footer .f2 .f21 h3");
  for (var i = 0; i < titles.length; i++) {
    titles[i].addEventListener("click", clickTitle);
  }
}

function stopEmptyLinks(event) {
  var link = event.target.closest("a");
  if (!link) {
    return;
  }
  var address = link.getAttribute("href");
  if (address === "" || address === "#") {
    event.preventDefault();
  }
}

function writeYear() {
  var year = document.getElementById("year");
  if (year) {
    year.textContent = new Date().getFullYear();
  }
}

function startPage() {
  startMenu();
  startBackTop();
  startReveal();
  startFooterMenu();
  writeYear();
  document.addEventListener("click", stopEmptyLinks);
  window.addEventListener("scroll", checkScroll);
  checkScroll();
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", startPage);
} else {
  startPage();
}
