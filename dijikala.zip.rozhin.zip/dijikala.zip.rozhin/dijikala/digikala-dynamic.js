/* =========================================================================
   digikala-dynamic.js
   ---------------------------------------------------------------------
   یک "دیتابیس" جیسونی برای اطلاعات صفحه اصلی دیجی‌کالا + توابعی که این
   اطلاعات رو به صورت داینامیک داخل HTML رندر می‌کنن (دقیقا شبیه ساختار
   دیجی‌کالا: استوری‌ها، اسلایدر پیشنهاد شگفت‌انگیز، بلک‌فرایدی، دسته‌بندی‌ها،
   برندها، پرفروش‌ترین‌ها و ...)

   نحوه استفاده:
   1) این فایل رو بعد از فایل‌های swiper و قبل از تگ بسته </body> لینک کن:
      <script src="./digikala-dynamic.js"></script>
   2) دیگه لازم نیست خودت آیتم‌ها رو ۱۰-۱۲ بار توی HTML کپی/پیست کنی،
      فقط کافیه کانتینر (والد) با همون کلاس‌های قبلی توی HTML باشه؛
      این اسکریپت محتوای داخلش رو پاک می‌کنه و از روی دیتابیس JSON می‌سازه.
   ========================================================================= */

(function () {
  "use strict";

  /* ======================= 1) دیتابیس JSON ============================ */
  const database = {
    stories: buildRepeated(10, () => ({
      img: "./pic/story2.jpg",
      text: "کنسرو اومیلو بگیرم؟",
    })),

    blackFriday: {
      items: buildRepeated(9, () => ({
        img: "./pic/blackkk.jpg",
        text: "از بلک فراید جا نمونی",
      })),
      more: { img: "./pic/bishtar.svg", text: "بیشتر" },
    },

    amazingOffers: {
      // مدت زمان باقی‌مانده تا پایان پیشنهاد شگفت‌انگیز؛ از همین لحظه شمارش
      // معکوس واقعی (روز/ساعت/دقیقه/ثانیه) شروع می‌شه و خودش هر ثانیه آپدیت میشه
      countdown: { days: 1, hours: 8, minutes: 3, seconds: 0 },
      banner: { icon: "./pic/Amazings.svg" },
      items: buildRepeated(7, () => ({
        img: "./pic/lab.webp",
        alt: "عکس شگفت انگیز",
        title: "ساعت سبز پولداری , زن و مرد هم نداره میتونی بخر",
        discountPercent: "5%",
        price: "29,000,000",
        oldPrice: "30,000,000",
        discountIcon: "./pic/svgexport-15.svg",
      })),
    },

    part2Banners: buildRepeated(4, () => ({ img: "./pic/part2.webp" })),

    supermarket: {
      freshImg: "./pic/fresh.webp",
      freshIcon: "./pic/supermarket.svg",
      freshDiscount: "تا 55%تخفیف",
      hyperItems: buildRepeated(6, () => ({
        img: "./pic/hipe.webp",
        discount: "50%",
      })),
      moreText: "بیش از 200 کالا",
      moreIcon: "./pic/bro.svg",
    },

    part22Banners: buildRepeated(4, () => ({ img: "./pic/part22.webp" })),

    categories: buildRepeated(16, () => ({
      img: "./pic/ahpaz.jpg",
      title: "خانه و اشپز خانه",
    })),

    brands: buildRepeated(9, () => ({ img: "./pic/dove.jpg" })),

    /* بخش‌های "box" (part7) که هرکدوم یک دسته کالا رو با ۴ عکس نشون میدن */
    boxSections: [
      {
        title: "گوشی موبایل",
        subtitle: "بر اساس سلیقه شما",
        images: [
          "./pic/Clock.jpg",
          "./pic/Clock.jpg",
          "./pic/Clock.jpg",
          "./pic/Clock.jpg",
        ],
        count: 3,
        extraClassOnLast: "box2",
      },
      {
        title: "لبتاپ و کامپیوتر",
        subtitle: "بر اساس سلیقه شما",
        images: [
          "./pic/lab.jpg",
          "./pic/lab.jpg",
          "./pic/lab.jpg",
          "./pic/lab.jpg",
        ],
        count: 4,
      },
    ],

    /* بخش‌های "پرفروش‌ترین‌ها" (part8) - هر کدوم لیست جدا */
    bestSellers: [
      {
        heading: "پرفروش ترین کالا ها",
        headingIcon: "./pic/star.svg",
        items: buildRepeated(12, () => ({
          img: "./pic/farmand.webp",
          rank: 1,
          name: "کرم کاکایو فندقی-- 300 گزمم",
        })),
      },
      {
        heading: "پرفروش ترین کالا ها",
        headingIcon: "./pic/star.svg",
        items: buildRepeated(10, () => ({
          img: "./pic/doll.webp",
          rank: 1,
          name: "ست اسباب بازی برگر",
        })),
      },
    ],

    deliveryFeatures: buildRepeated(5, () => ({
      icon: "./pic/express-delivery.svg",
      text: "امکان تحویل اکسپرس",
    })),

    digiplusBanners: buildRepeated(16, () => ({ img: "./pic/digiplus.svg" })),
  };

  /* کمک‌کننده: n بار fn رو اجرا می‌کنه و آرایه‌ای از خروجی‌ها می‌سازه
     (شبیه‌سازی رکوردهایی که قراره از یک دیتابیس واقعی/API بیان) */
  function buildRepeated(n, fn) {
    return Array.from({ length: n }, () => fn());
  }

  /* ======================= 2) ابزارهای کمکی DOM ======================== */
  function el(tag, props = {}, children = []) {
    const node = document.createElement(tag);
    Object.entries(props).forEach(([key, value]) => {
      if (key === "class") node.className = value;
      else if (key === "text") node.textContent = value;
      else node.setAttribute(key, value);
    });
    children.forEach((child) => node.appendChild(child));
    return node;
  }

  function img(src, alt = "", extraClass = "") {
    return el("img", { src, alt, ...(extraClass ? { class: extraClass } : {}) });
  }

  /* پاک کردن محتوای فعلی یک کانتینر قبل از رندر جدید */
  function clear(container) {
    if (container) container.innerHTML = "";
  }

  /* ======================= 3) توابع رندر هر بخش ========================= */

  function renderStories(data) {
    const container = document.querySelector(".story");
    if (!container) return;
    clear(container);
    data.forEach((story) => {
      const item = el("div", { class: "story1" }, [
        img(story.img, ""),
        el("a", { href: "#", text: story.text }),
      ]);
      container.appendChild(item);
    });
  }

  function renderBlackFriday(data) {
    const container = document.querySelector(".part");
    if (!container) return;
    clear(container);
    data.items.forEach((it) => {
      container.appendChild(
        el("div", { class: "part-1" }, [img(it.img, ""), el("a", { href: "#", text: it.text })])
      );
    });
    container.appendChild(
      el("div", { class: "part-1 bishtar" }, [
        img(data.more.img, ""),
        el("a", { href: "#", text: data.more.text }),
      ])
    );
  }

  /* شمارنده معکوس واقعی: روز/ساعت/دقیقه/ثانیه که هر ثانیه خودش کم میشه.
     برای اینکه با هر بار renderAll دوباره از اول شروع نشه، لحظه پایان
     (endTime) فقط یک‌بار محاسبه و روی خودِ آبجکت countdown ذخیره میشه. */
  let countdownIntervalId = null;

  function getCountdownEndTime(countdown) {
    if (!countdown.endTime) {
      const ms =
        (((countdown.days * 24 + countdown.hours) * 60 + countdown.minutes) * 60 +
          countdown.seconds) *
        1000;
      countdown.endTime = Date.now() + ms;
    }
    return countdown.endTime;
  }

  function startCountdown(countdown, spans) {
    if (countdownIntervalId) clearInterval(countdownIntervalId);

    const endTime = getCountdownEndTime(countdown);

    function tick() {
      let remainingMs = endTime - Date.now();
      if (remainingMs < 0) remainingMs = 0;

      const totalSeconds = Math.floor(remainingMs / 1000);
      const days = Math.floor(totalSeconds / 86400);
      const hours = Math.floor((totalSeconds % 86400) / 3600);
      const minutes = Math.floor((totalSeconds % 3600) / 60);
      const seconds = totalSeconds % 60;

      spans.days.textContent = String(days);
      spans.hours.textContent = String(hours).padStart(2, "0");
      spans.minutes.textContent = String(minutes).padStart(2, "0");
      spans.seconds.textContent = String(seconds).padStart(2, "0");

      if (remainingMs <= 0) {
        clearInterval(countdownIntervalId);
      }
    }

    tick(); // اجرای فوری برای جلوگیری از یک ثانیه تاخیر نمایش اول
    countdownIntervalId = setInterval(tick, 1000);
  }

  function renderAmazingOffers(data) {
    const wrapper = document.querySelector(".mySwiper .swiper-wrapper");
    if (!wrapper) return;
    clear(wrapper);

    const daySpan = el("span", { text: "1" });
    const hourSpan = el("span", { text: "08" });
    const minuteSpan = el("span", { text: "03" });
    const secondSpan = el("span", { text: "00" });

    const countdownSlide = el("div", { class: "swiper-slide" }, [
      el("div", { class: "shegeft" }, [
        el(
          "a",
          { href: "#" },
          [
            img(data.banner.icon, "", "offer1"),
            el("div", {}, [
              daySpan,
              document.createTextNode(" روز "),
              hourSpan,
              document.createTextNode(":"),
              minuteSpan,
              document.createTextNode(":"),
              secondSpan,
            ]),
            img(data.banner.icon.replace("Amazings", "Amazing"), "لبخند درصدی", "offer2"),
            el("span", { text: "مشاهده همه " }, [img("./pic/svgexport-8.svg", "")]),
          ]
        ),
      ]),
    ]);
    wrapper.appendChild(countdownSlide);

    startCountdown(data.countdown, {
      days: daySpan,
      hours: hourSpan,
      minutes: minuteSpan,
      seconds: secondSpan,
    });

    data.items.forEach((offer) => {
      const slide = el("div", { class: "swiper-slide" }, [
        el("div", { class: "box" }, [
          el("a", { href: "#" }, [
            img(offer.img, offer.alt),
            el("p", { text: offer.title }),
            el("div", {}, [
              el("span", { text: offer.discountPercent }),
              el("div", {}, [
                el("span", { text: offer.price }),
                img(offer.discountIcon, "درصد تخفیف"),
              ]),
            ]),
            el("span", { text: offer.oldPrice }),
          ]),
        ]),
      ]);
      wrapper.appendChild(slide);
    });

    // چون محتوای Swiper از نو ساخته شده، باید Swiper رو دوباره init/update کنیم
    if (window.mySwiperInstance) {
      window.mySwiperInstance.update();
    } else if (window.Swiper) {
      window.mySwiperInstance = new Swiper(".mySwiper", {
        slidesPerView: 8,
        spaceBetween: 5,
        freeMode: true,
      });
    }
  }

  function renderImageBanners(selector, data) {
    const container = document.querySelector(selector);
    if (!container) return;
    clear(container);
    data.forEach((banner) => {
      container.appendChild(el("div", {}, [img(banner.img, "")]));
    });
  }

  function renderSupermarket(data) {
    const container = document.querySelector(".part3");
    if (!container) return;
    clear(container);

    const p1 = el("div", { class: "p1" }, [
      img(data.freshImg, "", "p11"),
      img(data.freshIcon, "", "p12"),
      el("div", { class: "p13", text: data.freshDiscount }),
    ]);

    const p2 = el("div", { class: "p2" });
    data.hyperItems.forEach((hi) => {
      p2.appendChild(
        el("div", { class: "p21" }, [
          img(hi.img, ""),
          el("div", { class: "rounded-pill", text: hi.discount }),
        ])
      );
    });
    p2.appendChild(
      el("div", { class: "p22 rounded-pill" }, [
        el("span", { text: data.moreText }),
        img(data.moreIcon, ""),
      ])
    );

    container.appendChild(p1);
    container.appendChild(p2);
  }

  function renderCategories(data) {
    const container = document.querySelector(".part4");
    if (!container) return;
    // فقط تیتر بخش رو نگه می‌داریم و بقیه رو از نو می‌سازیم
    const title = container.querySelector(".txt");
    clear(container);
    if (title) container.appendChild(title);
    else container.appendChild(el("div", { class: "txt", text: "خرید بر اساس دسته بندی" }));

    data.forEach((cat) => {
      container.appendChild(
        el("div", { class: "p1" }, [img(cat.img, ""), el("span", { text: cat.title })])
      );
    });
  }

  function renderBrands(data) {
    const container = document.querySelector(".part6");
    if (!container) return;
    const nav = container.querySelector(".nav");
    clear(container);
    if (nav) container.appendChild(nav);
    else
      container.appendChild(
        el("div", { class: "nav" }, [img("./pic/star.svg", ""), el("span", { text: "محبوب ترین برند ها" })])
      );

    data.forEach((brand) => {
      container.appendChild(el("div", { class: "p6" }, [img(brand.img, "")]));
    });
  }

  function renderBoxSections(data) {
    const containers = document.querySelectorAll(".part7");
    containers.forEach((container, idx) => {
      const section = data[idx];
      if (!section) return;
      clear(container);
      const count = section.count || 3;
      for (let i = 0; i < count; i++) {
        const isLast = i === count - 1 && section.extraClassOnLast;
        const boxClass = isLast ? `box ${section.extraClassOnLast}` : "box";
        container.appendChild(
          el("div", { class: boxClass }, [
            el("div", { class: "txt1", text: section.title }),
            el("div", { class: "txt2", text: section.subtitle }),
            el("div", { class: "img" }, [
              img(section.images[0], ""),
              img(section.images[1], "", "i1"),
              img(section.images[2], "", "i3"),
              img(section.images[3], "", "i4"),
            ]),
            el("div", { class: "txt3" }, [
              el("span", { text: "مشاهده همه" }),
              img("./pic/b.svg", ""),
            ]),
          ])
        );
      }
    });
  }

  function renderBestSellers(data) {
    const containers = document.querySelectorAll(".part8");
    containers.forEach((container, idx) => {
      const section = data[idx];
      if (!section) return;
      clear(container);
      container.appendChild(
        el("div", { class: "p8" }, [img(section.headingIcon, ""), el("span", { text: section.heading })])
      );
      section.items.forEach((product) => {
        container.appendChild(
          el("div", { class: "p81" }, [
            img(product.img, ""),
            el("div", { class: "p82", text: String(product.rank) }),
            el("div", { class: "p83", text: product.name }),
          ])
        );
      });
    });
  }

  function renderDeliveryFeatures(data) {
    const container = document.querySelector(".part11");
    if (!container) return;
    clear(container);
    data.forEach((feature) => {
      container.appendChild(
        el("div", { class: "i1" }, [img(feature.icon, ""), el("span", { text: feature.text })])
      );
    });
  }

  function renderDigiplusBanners(data) {
    const container = document.querySelector(".part14");
    if (!container) return;
    clear(container);
    data.forEach((b) => {
      container.appendChild(el("div", { class: "img" }, [img(b.img, "")]));
    });
  }

  /* ======================= 4) اجرای همه‌چیز ============================ */
  function renderAll() {
    renderStories(database.stories);
    renderBlackFriday(database.blackFriday);
    renderAmazingOffers(database.amazingOffers);
    renderImageBanners(".part2", database.part2Banners);
    renderSupermarket(database.supermarket);
    renderImageBanners(".part22", database.part22Banners);
    renderCategories(database.categories);
    renderBrands(database.brands);
    renderBoxSections(database.boxSections);
    renderBestSellers(database.bestSellers);
    renderDeliveryFeatures(database.deliveryFeatures);
    renderDigiplusBanners(database.digiplusBanners);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", renderAll);
  } else {
    renderAll();
  }

  /* در دسترس گذاشتن دیتابیس و توابع برای دستکاری بعدی از کنسول یا اسکریپت‌های دیگه
     مثال: window.digikalaDB.database.categories.push({img:"x.jpg", title:"تست"})
     بعد: window.digikalaDB.renderAll() */
  window.digikalaDB = { database, renderAll };
})();