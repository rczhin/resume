var cart = [];
var searchMatches = [];
var allStories = [];
var storyNumber = 0;
var storyTimer = null;
var messageTimer = null;
var userPhone = "";

var toast;
var overlay;
var windowTitle;
var windowBody;
var cartNumber;
var searchList;
var searchInput;

function readSaved(key) {
  try {
    return localStorage.getItem(key);
  } catch (error) {
    return null;
  }
}

function writeSaved(key, value) {
  try {
    localStorage.setItem(key, value);
  } catch (error) {}
}

function toEnglish(text) {
  var persian = "۰۱۲۳۴۵۶۷۸۹";
  var arabic = "٠١٢٣٤٥٦٧٨٩";
  var result = "";
  for (var i = 0; i < text.length; i++) {
    var letter = text.charAt(i);
    var place = persian.indexOf(letter);
    if (place === -1) {
      place = arabic.indexOf(letter);
    }
    if (place !== -1) {
      letter = String(place);
    }
    result += letter;
  }
  return result;
}

function formatNumber(number) {
  return number.toLocaleString("en-US");
}

function addStyle() {
  var style = document.createElement("style");
  style.textContent = `
    .header { z-index: 50; transition: box-shadow 0.3s; }
    .header .icon { position: relative; }
    .header .icon > img, .header .ic1, .posht, .posht2, .story1, nav .n2, nav .n1 li { cursor: pointer; }
    .posht, .posht2 { z-index: 40; }
    #toast { position: fixed; bottom: 30px; left: 50%; transform: translateX(-50%); background: #3f4064; color: #fff; padding: 12px 24px; border-radius: 10px; font-size: 14px; opacity: 0; transition: opacity 0.3s; z-index: 3000; pointer-events: none; }
    #cartNumber { position: absolute; min-width: 18px; height: 18px; background: #ef394e; color: #fff; font-size: 11px; border-radius: 9px; text-align: center; line-height: 18px; display: none; pointer-events: none; padding: 0 4px; }
    #overlay { position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0, 0, 0, 0.6); display: none; align-items: center; justify-content: center; z-index: 2000; }
    #windowBox { background: #fff; width: 460px; max-width: 92%; max-height: 85vh; overflow: auto; border-radius: 16px; padding: 16px; }
    #windowTop { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; font-size: 18px; color: #3f4064; }
    #windowClose { border: 0; background: #eee; width: 32px; height: 32px; border-radius: 50%; font-size: 20px; cursor: pointer; }
    .cartRow { display: flex; align-items: center; gap: 8px; padding: 8px 0; border-bottom: 1px solid #eee; }
    .cartRow img { width: 60px; height: 60px; object-fit: contain; }
    .cartName { flex: 1; font-size: 12px; line-height: 20px; }
    .smallButton { border: 1px solid #ddd; background: #fff; width: 26px; height: 26px; border-radius: 6px; cursor: pointer; }
    .bigButton { background: #ef394e; color: #fff; border: 0; padding: 10px 18px; border-radius: 8px; cursor: pointer; font-size: 14px; }
    .grayButton { background: #eee; color: #333; border: 0; padding: 10px 18px; border-radius: 8px; cursor: pointer; font-size: 14px; }
    .cityButton { margin: 4px; padding: 8px 14px; border: 1px solid #ddd; border-radius: 20px; background: #fff; cursor: pointer; font-size: 14px; }
    .cityButton:hover { border-color: #ef394e; color: #ef394e; }
    .windowInput { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 8px; margin-bottom: 8px; font-size: 14px; }
    .errorText { color: #ef394e; font-size: 12px; min-height: 18px; margin-bottom: 6px; }
    #searchList { position: fixed; background: #fff; border: 1px solid #ddd; border-radius: 8px; box-shadow: 0 4px 14px rgba(0, 0, 0, 0.15); z-index: 1500; display: none; overflow: hidden; }
    #searchList div { padding: 10px 14px; font-size: 14px; cursor: pointer; color: #3f4064; }
    #searchList div:hover { background: #f2f2f2; }
    .addButton { background: #3f4064; color: #fff; border: 0; width: 100%; padding: 6px; font-size: 12px; border-radius: 6px; margin-top: 4px; cursor: pointer; }
    .addButton:hover { background: #24012f; }
    .storyImage { width: 100%; max-height: 55vh; object-fit: contain; border-radius: 12px; }
    .storyBar { height: 4px; background: #ddd; border-radius: 2px; margin-bottom: 10px; overflow: hidden; }
    .storyBar div { height: 100%; width: 0; background: #ef394e; transition: width 4s linear; }
  `;
  document.head.appendChild(style);
}

function makeBase() {
  toast = document.createElement("div");
  toast.id = "toast";
  document.body.appendChild(toast);

  overlay = document.createElement("div");
  overlay.id = "overlay";
  overlay.innerHTML =
    '<div id="windowBox"><div id="windowTop"><span id="windowTitle"></span><button id="windowClose">×</button></div><div id="windowBody"></div></div>';
  document.body.appendChild(overlay);

  windowTitle = document.getElementById("windowTitle");
  windowBody = document.getElementById("windowBody");

  document.getElementById("windowClose").addEventListener("click", closeWindow);
  overlay.addEventListener("click", function (event) {
    if (event.target === overlay) {
      closeWindow();
    }
  });
  windowBody.addEventListener("click", clickWindow);

  searchList = document.createElement("div");
  searchList.id = "searchList";
  document.body.appendChild(searchList);

  cartNumber = document.createElement("div");
  cartNumber.id = "cartNumber";
  var cartIcon = document.querySelector(".header .icon > img");
  if (cartIcon) {
    cartIcon.parentNode.appendChild(cartNumber);
    cartNumber.style.left = cartIcon.offsetLeft + 2 + "px";
    cartNumber.style.top = cartIcon.offsetTop + 2 + "px";
  } else {
    document.body.appendChild(cartNumber);
  }
}

function showMessage(text) {
  toast.textContent = text;
  toast.style.opacity = "1";
  clearTimeout(messageTimer);
  messageTimer = setTimeout(function () {
    toast.style.opacity = "0";
  }, 2500);
}

function openWindow(title) {
  clearTimeout(storyTimer);
  windowTitle.textContent = title;
  windowBody.innerHTML = "";
  overlay.style.display = "flex";
  return windowBody;
}

function closeWindow() {
  clearTimeout(storyTimer);
  overlay.style.display = "none";
}

function loadCart() {
  var text = readSaved("cart");
  if (text) {
    try {
      cart = JSON.parse(text);
    } catch (error) {
      cart = [];
    }
  }
  if (!Array.isArray(cart)) {
    cart = [];
  }
}

function saveCart() {
  writeSaved("cart", JSON.stringify(cart));
}

function countAll() {
  var total = 0;
  for (var i = 0; i < cart.length; i++) {
    total += cart[i].count;
  }
  return total;
}

function priceAll() {
  var total = 0;
  for (var i = 0; i < cart.length; i++) {
    total += cart[i].price * cart[i].count;
  }
  return total;
}

function updateNumber() {
  var total = countAll();
  cartNumber.textContent = total;
  if (total > 0) {
    cartNumber.style.display = "block";
  } else {
    cartNumber.style.display = "none";
  }
}

function addButtons() {
  var boxes = document.querySelectorAll(".mySwiper .box");
  for (var i = 0; i < boxes.length; i++) {
    if (boxes[i].querySelector(".addButton")) {
      continue;
    }
    var button = document.createElement("button");
    button.className = "addButton";
    button.textContent = "افزودن به سبد";
    boxes[i].appendChild(button);
  }
}

function fixSlider() {
  if (window.mySwiperInstance) {
    window.mySwiperInstance.update();
  }
  if (window.swiper && window.swiper.update) {
    window.swiper.update();
  }
}

function addToCart(box) {
  if (!box) {
    return;
  }
  var titleTag = box.querySelector("p");
  var priceTag = box.querySelector("a > div > div > span");
  var imageTag = box.querySelector("img");
  if (!titleTag || !priceTag || !imageTag) {
    return;
  }

  var name = titleTag.textContent.trim();
  var price = Number(priceTag.textContent.replace(/[^0-9]/g, ""));
  var image = imageTag.getAttribute("src");

  var found = false;
  for (var i = 0; i < cart.length; i++) {
    if (cart[i].name === name && cart[i].price === price) {
      cart[i].count += 1;
      found = true;
    }
  }
  if (!found) {
    cart.push({ name: name, price: price, image: image, count: 1 });
  }

  saveCart();
  updateNumber();
  showMessage("به سبد خرید اضافه شد");
}

function openCart() {
  var body = openWindow("سبد خرید");
  if (cart.length === 0) {
    body.innerHTML = '<p style="text-align:center;padding:30px">سبد خرید شما خالی است</p>';
    return;
  }

  var html = "";
  for (var i = 0; i < cart.length; i++) {
    var item = cart[i];
    html +=
      '<div class="cartRow">' +
      '<img src="' + item.image + '">' +
      '<div class="cartName">' + item.name + "<br><b>" + formatNumber(item.price) + " تومان</b></div>" +
      '<button class="smallButton" data-do="plus" data-number="' + i + '">+</button>' +
      "<span>" + item.count + "</span>" +
      '<button class="smallButton" data-do="minus" data-number="' + i + '">-</button>' +
      '<button class="smallButton" data-do="remove" data-number="' + i + '">×</button>' +
      "</div>";
  }
  html +=
    '<p style="margin:14px 0"><b>جمع کل: ' + formatNumber(priceAll()) + " تومان</b></p>" +
    '<button class="bigButton" data-do="pay">ادامه خرید</button> ' +
    '<button class="grayButton" data-do="empty">خالی کردن سبد</button>';
  body.innerHTML = html;
}

function plusOne(number) {
  if (!cart[number]) {
    return;
  }
  cart[number].count += 1;
  saveCart();
  updateNumber();
  openCart();
}

function minusOne(number) {
  if (!cart[number]) {
    return;
  }
  if (cart[number].count > 1) {
    cart[number].count -= 1;
    saveCart();
    updateNumber();
    openCart();
  } else {
    removeOne(number);
  }
}

function removeOne(number) {
  cart.splice(number, 1);
  saveCart();
  updateNumber();
  openCart();
}

function emptyCart() {
  cart = [];
  saveCart();
  updateNumber();
  openCart();
}

function payCart() {
  closeWindow();
  showMessage("در حال انتقال به صفحه پرداخت...");
}

function showSuggestions() {
  var word = searchInput.value.trim();
  searchList.innerHTML = "";
  searchMatches = [];

  if (word === "") {
    searchList.style.display = "none";
    return;
  }

  var found = document.querySelectorAll(".p83, .mySwiper .box p, .part4 .p1 span, .story1 a, .part-1 a");
  for (var i = 0; i < found.length; i++) {
    var text = found[i].textContent.trim();
    if (text.indexOf(word) === -1) {
      continue;
    }
    var already = false;
    for (var j = 0; j < searchMatches.length; j++) {
      if (searchMatches[j].text === text) {
        already = true;
      }
    }
    if (already) {
      continue;
    }
    searchMatches.push({ text: text, element: found[i] });
    if (searchMatches.length === 6) {
      break;
    }
  }

  if (searchMatches.length === 0) {
    searchList.innerHTML = "<div>موردی پیدا نشد</div>";
  } else {
    for (var k = 0; k < searchMatches.length; k++) {
      var row = document.createElement("div");
      row.textContent = searchMatches[k].text;
      row.setAttribute("data-number", k);
      searchList.appendChild(row);
    }
  }

  var place = searchInput.getBoundingClientRect();
  searchList.style.top = place.bottom + 4 + "px";
  searchList.style.left = place.left + "px";
  searchList.style.width = place.width + "px";
  searchList.style.display = "block";
}

function goToItem(number) {
  var item = searchMatches[number];
  if (!item) {
    return;
  }
  searchInput.value = item.text;
  searchList.style.display = "none";
  item.element.scrollIntoView({ behavior: "smooth", block: "center" });
  item.element.style.outline = "3px solid #ef394e";
  setTimeout(function () {
    item.element.style.outline = "";
  }, 2500);
}

function setupSearch() {
  searchInput = document.querySelector(".header input");
  if (!searchInput) {
    return;
  }
  searchInput.addEventListener("input", showSuggestions);
  searchInput.addEventListener("keydown", function (event) {
    if (event.key === "Enter") {
      showSuggestions();
      if (searchMatches.length > 0) {
        goToItem(0);
      } else {
        showMessage("موردی پیدا نشد");
      }
    }
  });
  searchList.addEventListener("click", function (event) {
    var row = event.target.closest("div[data-number]");
    if (row) {
      goToItem(Number(row.getAttribute("data-number")));
    }
  });
}

function showStory(number) {
  clearTimeout(storyTimer);
  storyNumber = number;

  var story = allStories[number];
  var image = story.querySelector("img");
  var link = story.querySelector("a");

  image.style.backgroundImage = "none";
  image.style.backgroundColor = "#c9c9c9";

  var body = openWindow("استوری " + (number + 1) + " از " + allStories.length);
  body.innerHTML =
    '<div class="storyBar"><div id="storyFill"></div></div>' +
    '<img class="storyImage" src="' + image.getAttribute("src") + '">' +
    '<p style="text-align:center;margin:12px 0">' + link.textContent + "</p>" +
    '<div style="display:flex;justify-content:space-between">' +
    '<button class="grayButton" data-do="backStory">قبلی</button>' +
    '<button class="grayButton" data-do="nextStory">بعدی</button>' +
    "</div>";

  setTimeout(function () {
    var fill = document.getElementById("storyFill");
    if (fill) {
      fill.style.width = "100%";
    }
  }, 50);

  storyTimer = setTimeout(nextStory, 4000);
}

function nextStory() {
  if (storyNumber + 1 < allStories.length) {
    showStory(storyNumber + 1);
  } else {
    closeWindow();
  }
}

function backStory() {
  if (storyNumber > 0) {
    showStory(storyNumber - 1);
  }
}

function openStory(story) {
  allStories = document.querySelectorAll(".story1");
  for (var i = 0; i < allStories.length; i++) {
    if (allStories[i] === story) {
      showStory(i);
    }
  }
}

function showCity(cityName) {
  var span = document.querySelector("nav .n2 span");
  if (span) {
    span.textContent = cityName;
  }
}

function loadCity() {
  var cityName = readSaved("city");
  if (cityName) {
    showCity(cityName);
  }
}

function openCity() {
  var body = openWindow("انتخاب شهر");
  var cities = ["تهران", "اصفهان", "مشهد", "شیراز", "تبریز", "اهواز", "رشت", "کرمان", "یزد", "قم"];
  var html = "";
  for (var i = 0; i < cities.length; i++) {
    html += '<button class="cityButton" data-do="city" data-name="' + cities[i] + '">' + cities[i] + "</button>";
  }
  body.innerHTML = html;
}

function chooseCity(cityName) {
  writeSaved("city", cityName);
  showCity(cityName);
  closeWindow();
  showMessage("شهر شما " + cityName + " شد");
}

function showLoginName() {
  var loginText = document.querySelector(".header span.ic11");
  var signText = document.querySelector(".header span.ic1");
  if (loginText) {
    loginText.textContent = userPhone ? "حساب من" : "ورود";
  }
  if (signText) {
    signText.style.display = userPhone ? "none" : "";
  }
}

function loadPhone() {
  var phone = readSaved("phone");
  if (phone) {
    userPhone = phone;
  }
  showLoginName();
}

function openLogin() {
  if (userPhone) {
    var account = openWindow("حساب من");
    account.innerHTML =
      '<p style="margin-bottom:14px">شماره شما: <b>' + userPhone + "</b></p>" +
      '<button class="bigButton" data-do="logout">خروج از حساب</button>';
    return;
  }
  var body = openWindow("ورود یا ثبت نام");
  body.innerHTML =
    '<p style="margin-bottom:8px">شماره موبایل خود را وارد کنید</p>' +
    '<input id="phoneInput" class="windowInput" placeholder="09123456789">' +
    '<div id="phoneError" class="errorText"></div>' +
    '<button class="bigButton" data-do="login">ادامه</button>';
  document.getElementById("phoneInput").focus();
}

function checkLogin() {
  var input = document.getElementById("phoneInput");
  var error = document.getElementById("phoneError");
  if (!input) {
    return;
  }
  var text = toEnglish(input.value.trim());
  if (/^09[0-9]{9}$/.test(text)) {
    userPhone = text;
    writeSaved("phone", text);
    showLoginName();
    closeWindow();
    showMessage("خوش آمدید");
  } else {
    error.textContent = "شماره موبایل درست نیست";
  }
}

function logoutUser() {
  userPhone = "";
  writeSaved("phone", "");
  showLoginName();
  closeWindow();
  showMessage("از حساب خارج شدید");
}

function openHelp() {
  var body = openWindow("پشتیبانی");
  body.innerHTML =
    '<p style="margin-bottom:8px">تلفن پشتیبانی: ۶۱۹۳۰۰۰۰ - ۰۲۱</p>' +
    '<textarea id="helpText" class="windowInput" rows="4" placeholder="پیام خود را بنویسید"></textarea>' +
    '<button class="bigButton" data-do="sendHelp">ارسال پیام</button>';
}

function sendHelp() {
  var box = document.getElementById("helpText");
  if (!box || box.value.trim() === "") {
    showMessage("لطفا پیام خود را بنویسید");
    return;
  }
  closeWindow();
  showMessage("پیام شما ثبت شد");
}

function setupEmail() {
  var input = document.querySelector(".part12 input");
  if (!input) {
    return;
  }
  input.addEventListener("keydown", function (event) {
    if (event.key !== "Enter") {
      return;
    }
    var email = input.value.trim();
    if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      input.value = "";
      showMessage("ایمیل شما ثبت شد");
    } else {
      showMessage("ایمیل را درست وارد کنید");
    }
  });
}

function clickWindow(event) {
  var button = event.target.closest("button");
  if (!button) {
    return;
  }
  var what = button.getAttribute("data-do");
  var number = Number(button.getAttribute("data-number"));

  if (what === "plus") {
    plusOne(number);
  } else if (what === "minus") {
    minusOne(number);
  } else if (what === "remove") {
    removeOne(number);
  } else if (what === "empty") {
    emptyCart();
  } else if (what === "pay") {
    payCart();
  } else if (what === "city") {
    chooseCity(button.getAttribute("data-name"));
  } else if (what === "login") {
    checkLogin();
  } else if (what === "logout") {
    logoutUser();
  } else if (what === "sendHelp") {
    sendHelp();
  } else if (what === "nextStory") {
    nextStory();
  } else if (what === "backStory") {
    backStory();
  }
}

function clickPage(event) {
  var target = event.target;

  if (!target.closest("#searchList") && target !== searchInput) {
    searchList.style.display = "none";
  }

  var link = target.closest("a");
  if (link) {
    var address = link.getAttribute("href");
    if (address === "" || address === "#") {
      event.preventDefault();
    }
  }

  if (target.closest(".addButton")) {
    addToCart(target.closest(".box"));
    return;
  }

  if (target.closest(".header .icon > img")) {
    openCart();
    return;
  }

  if (target.closest(".header .ic1")) {
    openLogin();
    return;
  }

  if (target.closest(".posht2")) {
    var market = document.querySelector(".part3");
    if (market) {
      market.scrollIntoView({ behavior: "smooth", block: "center" });
    }
    return;
  }

  if (target.closest(".posht")) {
    openHelp();
    return;
  }

  if (target.closest("nav .n2")) {
    openCity();
    return;
  }

  var story = target.closest(".story1");
  if (story) {
    openStory(story);
    return;
  }

  var menuItem = target.closest("nav .n1 li");
  if (menuItem) {
    var allLinks = document.querySelectorAll("nav .n1 li a");
    for (var i = 0; i < allLinks.length; i++) {
      allLinks[i].style.color = "";
    }
    var menuLink = menuItem.querySelector("a");
    if (menuLink) {
      menuLink.style.color = "#ef394e";
    }
    return;
  }

  if (target.closest(".part10 > a")) {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
}

function pressKey(event) {
  if (event.key === "Escape") {
    closeWindow();
  }
  if (event.key === "Enter" && event.target.id === "phoneInput") {
    checkLogin();
  }
}

function scrollPage() {
  var header = document.querySelector(".header");
  if (!header) {
    return;
  }
  if (window.scrollY > 10) {
    header.style.boxShadow = "0 2px 10px rgba(0, 0, 0, 0.15)";
  } else {
    header.style.boxShadow = "none";
  }
}

function startPage() {
  addStyle();
  makeBase();
  loadCart();
  updateNumber();
  addButtons();
  fixSlider();
  loadCity();
  loadPhone();
  setupSearch();
  setupEmail();
  document.addEventListener("click", clickPage);
  document.addEventListener("keydown", pressKey);
  window.addEventListener("scroll", scrollPage);
  scrollPage();
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", startPage);
} else {
  startPage();
}
